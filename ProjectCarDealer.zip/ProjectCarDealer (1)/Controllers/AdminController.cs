﻿using ProjectCarDealer.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProjectCarDealer.Controllers
{
   
    public class AdminController : Controller
    {
        private readonly SWPDBFA21Context _context;
        public AdminController(SWPDBFA21Context context)
        {
            this._context = context;
        }
        /// <summary>
        /// Index
        /// </summary>
        /// <returns>Index HelloPage</returns>
        public IActionResult Index()
        {
            string cus_name = HttpContext.Session.GetString("cus_name");
            ViewData["cus_name"] = cus_name;
            if (HttpContext.Session.GetString("cus_name") == null)
            {
                return RedirectToAction("Index", "Login");
            }
            else
            {
                var user = _context.Accounts.Where(x => x.Username == cus_name).FirstOrDefault();
                bool checkRole = user.IsAdmin;
                if (checkRole)
                {
                    ViewData["GetSession"] = "Hello Admin " + HttpContext.Session.GetString("cus_name");
                    return View();
                }
                else
                {
                    return RedirectToAction("Index", "HelloPage");
                }            
            }
           
        }
    }
}
