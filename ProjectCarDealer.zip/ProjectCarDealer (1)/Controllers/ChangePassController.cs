﻿using ProjectCarDealer.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NToastNotify;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace ProjectCarDealer.Controllers
{
    public class ChangePassController : Controller
    {
        private readonly SWPDBFA21Context _context;
        private readonly IToastNotification _notyf;
        public ChangePassController(SWPDBFA21Context context, IToastNotification notyf)
        {
            this._context = context;
            this._notyf = notyf;
        }

        /// <summary>
        ///Index
        /// </summary>
        /// <returns>Index Login</returns>
        public IActionResult Index()
        {
            if (HttpContext.Session.GetString("cus_name") == null)
            {
                return RedirectToAction("Index", "Login");
            }
            else
            {
                return View();
            }
        }

        /// <summary>
        ///GetHash
        /// </summary>
        /// <returns>Index</returns>
        public static string GetHash(string plainText)
        {
            MD5 md5 = new MD5CryptoServiceProvider();
            // Compute hash from the bytes of text
            md5.ComputeHash(ASCIIEncoding.ASCII.GetBytes(plainText));
            // Get hash result after compute it
            byte[] result = md5.Hash;
            StringBuilder strBuilder = new StringBuilder();
            for (int i = 0; i < result.Length; i++)
            {
                strBuilder.Append(result[i].ToString("x2"));
            }

            return strBuilder.ToString();
        }
        
        /// <summary>
        ///ChangePass
        /// </summary>
        /// <returns>Index</returns>
        public IActionResult ChangePass(ChangePassModelView us)
        {
            string inputPass = us.pass;
            string inputNewPass = us.newPass;
            string inputConfirmPass = us.confirmPass;
            string username = HttpContext.Session.GetString("cus_name");
            //check inputPass,inputConfirmPass,inputNewPass is null
            if (inputPass == null || inputConfirmPass == null || inputNewPass == null ){
                return View("Index");
            } else {
                if (ModelState.IsValid)
                {
                    var obj = _context.Accounts.Where(x => x.Username == username && x.Userpassword == GetHash(inputPass)).FirstOrDefault();
                    //check obj null
                    if (obj == null)
                    {
                        this._notyf.AddErrorToastMessage("Wrong Current Password please input again");
                        return View("Index");
                    }
                    else
                    {
                        //check inputNewPass
                        if (inputPass.Equals(inputNewPass) == true)
                        {
                            _notyf.AddWarningToastMessage("The new password cannot be the same as the current password ");
                            return View("Index");
                        }
                        else if (inputNewPass.Equals(inputConfirmPass) == true)//check inputNewPass same inputConfirmPass
                        {
                            //create GetHash MD5 give NewPass
                            obj.Userpassword = GetHash(inputNewPass);
                            _context.Update(obj);
                            _context.SaveChanges();
                            this._notyf.AddSuccessToastMessage("Your Password has been change successfully");
                            return RedirectToAction("Index", "Home");
                        }
                        else
                        {
                            this._notyf.AddErrorToastMessage("Confirm Password doesn't matching with New Password");
                            return View("Index");
                        }
                    }
                }
                return View("Index");
            }
        }
    }
}
