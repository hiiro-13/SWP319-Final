﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ProjectCarDealer.Models;

namespace ProjectCarDealer.Controllers
{
    public class OrderProductsController : Controller
    {
        private readonly SWPDBFA21Context _context;

        public OrderProductsController(SWPDBFA21Context context)
        {
            _context = context;
        }

        /// <summary>
        /// Index
        /// </summary>
        /// <returns>await sWPDBFA21Context.ToListAsync()</returns>
        public async Task<IActionResult> Index()
        {
            var sWPDBFA21Context = _context.OrderProducts.Include(o => o.Acc).Include(o => o.Pod).Include(o => o.Tra);
            return View(await sWPDBFA21Context.ToListAsync());
        }

        /// <summary>
        /// Details
        /// </summary>
        /// <returns>orderProduct</returns>
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var orderProduct = await _context.OrderProducts
                .Include(o => o.Acc)
                .Include(o => o.Pod)
                .Include(o => o.Tra)
                .FirstOrDefaultAsync(m => m.OrdId == id);
            if (orderProduct == null)
            {
                return NotFound();
            }

            return View(orderProduct);
        }

        /// <summary>
        /// Create
        /// </summary>
        /// <returns>orderProduct</returns>
        public IActionResult Create()
        {
            ViewData["AccId"] = new SelectList(_context.Accounts, "AccId", "Address");
            ViewData["PodId"] = new SelectList(_context.Products, "PodId", "GearType");
            ViewData["TraId"] = new SelectList(_context.TransactionMethods, "TraId", "PaymentInfo");
            return View();
        }

        /// <summary>
        /// Create
        /// </summary>
        /// <returns>orderProduct</returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("OrdId,AccId,PodId,TraId,Quantity,OrdStatus,DateCreated")] OrderProduct orderProduct)
        {
            if (ModelState.IsValid)
            {
                _context.Add(orderProduct);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["AccId"] = new SelectList(_context.Accounts, "AccId", "Address", orderProduct.AccId);
            ViewData["PodId"] = new SelectList(_context.Products, "PodId", "GearType", orderProduct.PodId);
            ViewData["TraId"] = new SelectList(_context.TransactionMethods, "TraId", "PaymentInfo", orderProduct.TraId);
            return View(orderProduct);
        }

        /// <summary>
        /// Edit
        /// </summary>
        /// <returns>orderProduct</returns>
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var orderProduct = await _context.OrderProducts.FindAsync(id);
            if (orderProduct == null)
            {
                return NotFound();
            }
            ViewData["AccId"] = new SelectList(_context.Accounts, "AccId", "Address", orderProduct.AccId);
            ViewData["PodId"] = new SelectList(_context.Products, "PodId", "GearType", orderProduct.PodId);
            ViewData["TraId"] = new SelectList(_context.TransactionMethods, "TraId", "PaymentInfo", orderProduct.TraId);
            return View(orderProduct);
        }

        /// <summary>
        /// Edit
        /// </summary>
        /// <returns>orderProduct</returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("OrdId,AccId,PodId,TraId,Quantity,OrdStatus,DateCreated")] OrderProduct orderProduct)
        {
            if (id != orderProduct.OrdId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(orderProduct);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!OrderProductExists(orderProduct.OrdId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["AccId"] = new SelectList(_context.Accounts, "AccId", "Address", orderProduct.AccId);
            ViewData["PodId"] = new SelectList(_context.Products, "PodId", "GearType", orderProduct.PodId);
            ViewData["TraId"] = new SelectList(_context.TransactionMethods, "TraId", "PaymentInfo", orderProduct.TraId);
            return View(orderProduct);
        }

       /// <summary>
        /// Delete
        /// </summary>
        /// <returns>orderProduct</returns>
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var orderProduct = await _context.OrderProducts
                .Include(o => o.Acc)
                .Include(o => o.Pod)
                .Include(o => o.Tra)
                .FirstOrDefaultAsync(m => m.OrdId == id);
            if (orderProduct == null)
            {
                return NotFound();
            }

            return View(orderProduct);
        }

        /// <summary>
        /// Delete
        /// </summary>
        /// <returns>orderProduct</returns>
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var orderProduct = await _context.OrderProducts.FindAsync(id);
            _context.OrderProducts.Remove(orderProduct);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool OrderProductExists(int id)
        {
            return _context.OrderProducts.Any(e => e.OrdId == id);
        }
    }
}
