﻿using ProjectCarDealer.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Net;
using System.Net.Mail;
using System.Drawing;
using System.Configuration;
using MimeKit;
using MailKit.Net.Smtp;
using System.Text;
using System.Security.Cryptography;
using NToastNotify;

namespace ProjectCarDealer.Controllers
{
    public class ForgotPassController : Controller
    {
      
        private readonly SWPDBFA21Context _accountDb;
        private readonly IToastNotification _notyf;
        public ForgotPassController(SWPDBFA21Context accounntDb, IToastNotification notyf)
        {
            this._accountDb = accounntDb;
            this._notyf = notyf;
        }

        
        public IActionResult Index()
        {
            
            return View();
        }
        /// <summary>
        ///GetHash
        /// </summary>
        /// <returns>Index Home</returns>
        public static string GetHash(string plainText)
        {
            MD5 md5 = new MD5CryptoServiceProvider();
            // Compute hash from the bytes of text
            md5.ComputeHash(ASCIIEncoding.ASCII.GetBytes(plainText));
            // Get hash result after compute it
            byte[] result = md5.Hash;
            StringBuilder strBuilder = new StringBuilder();
            for (int i = 0; i < result.Length; i++)
            {
                strBuilder.Append(result[i].ToString("x2"));
            }

            return strBuilder.ToString();
        }
        /// <summary>
        ///CreateRandomPassword
        /// </summary>
        /// <returns>Index Home</returns>
        private static string CreateRandomPassword(int length = 15)
        {
            // Create a string of characters, numbers, special characters that allowed in the password  
            string validChars = "ABCDEFGHJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*?_-";
            Random random = new Random();

            // Select one random character at a time from the string  
            // and create an array of chars  
            char[] chars = new char[length];
            for (int i = 0; i < length; i++)
            {
                chars[i] = validChars[random.Next(0, validChars.Length)];
            }
            return new string(chars);
        }

        [HttpPost]
        public IActionResult sendMailResetPass(ForgotPassModelView us)
        {
            string inputName = us.name;
            string inputMail = us.email;
            if (inputName == null || inputMail == null)
            {
                _notyf.AddErrorToastMessage("UserName or Email Cannot Be Blank !!");
                return View("Index");
            }
            else 
            {
                var obj = _accountDb.Accounts.Where(x => x.Username == us.name && x.Email == us.email).FirstOrDefault();
                if (obj == null)
                {
                    _notyf.AddErrorToastMessage("Username or Email invalid");
                    return View("Index");
                }
                else 
                {
                    string ranPass = CreateRandomPassword();
                    string PassIntoMail = ranPass;
                    obj.Userpassword = GetHash(ranPass);
                    _accountDb.Update(obj);
                    _accountDb.SaveChanges();
                    var message = new MimeMessage();
                    message.From.Add(new MailboxAddress("Car Dealer Web Application", "poghhhhgaming@gmail.com"));
                    message.To.Add(new MailboxAddress(us.name, us.email));
                    message.Subject = "Change your password";
                    message.Body = new TextPart("plain")
                    {
                        Text = "Your Password is : "+PassIntoMail+"\n"
                        + "Please login and change your password"

                    };
                    using (var client = new MailKit.Net.Smtp.SmtpClient())
                    {
                        client.Connect("smtp.gmail.com", 587, false);
                        client.Authenticate("poghhhhgaming@gmail.com", "vo thanh phong 1712");
                        client.Send(message);
                        client.Disconnect(true);
                    }
                    return RedirectToAction("Index", "Login");
                }
                
            }       
        }


    }

   
}
