﻿using DNTCaptcha.Core;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using NToastNotify;
using ProjectCarDealer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProjectCarDealer.Controllers
{
    public class DealerController : Controller
    {
        private readonly SWPDBFA21Context _context;
        private readonly IToastNotification _notyf;
        public DealerController(SWPDBFA21Context context, IToastNotification notyf)
        {
            _context = context;
            this._notyf = notyf;
        }

        /// <summary>
        ///Index
        /// </summary>
        /// <returns>Index</returns>
        public IActionResult Index()
        {
            string cus_name = HttpContext.Session.GetString("cus_name");
            ViewData["cus_name"] = cus_name;
            if (cus_name == null)
            {
                return View();
            }
            else
            {
                var obj = _context.Accounts.Where(x => x.Username == cus_name).FirstOrDefault();
                ViewBag.AccID = obj.AccId;
                ViewBag.Today = DateTime.Now;
                
                return View();
            }   
        }
        
        /// <su
        ///Create
        /// </summary>
        /// <returns>Index Product</returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("PodId,AccId,CatId,PodName,PodImage,PodDescription,VinNumber,GearType,Price,Quantity,PodStatus,DateCreated,Valid")] Product product)
        {
            if (ModelState.IsValid)
            {
                _context.Add(product);
                await _context.SaveChangesAsync();
                /*_notifyService.Success("Create Products successfully");*/
                return RedirectToAction("Index", "Product");
            }
            else
            {
                _notyf.AddAlertToastMessage("Field is required, cannot be blank");
                return RedirectToAction("Index", "Dealer");
            }
        }
    }
}
