﻿using ProjectCarDealer.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Security.Cryptography;
using System.Text;
using Microsoft.AspNetCore.Http;

namespace ProjectCarDealer.Areas.User.Controllers
{
    public class UserController : Controller
    {
        private readonly SWPDBFA21Context _context;
        
        
        public UserController(SWPDBFA21Context contexts)
        {
            this._context = contexts;
        }
        /// <summary>
        /// Index
        /// </summary>
        /// <returns>list</returns>
        public IActionResult Index()
        {
            string cus_name = HttpContext.Session.GetString("cus_name");
            ViewData["cus_name"] = cus_name;
            var list = _context.Accounts;
            

            return View(list);
        }
        /// <summary>
        /// Edit
        /// </summary>
        /// <returns>View</returns>
        public async Task<IActionResult> Edit(int? id)
        {
            
            if (id == null || id < 0)
            {
                return NotFound();
            }

            var doituong = await _context.Accounts.FindAsync(id);
            if (doituong == null)
            {
                return NotFound();
            }
            
            return View(doituong);
        }
        /// <summary>
        /// Edit
        /// </summary>
        /// <returns>View</returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Account accUp)
        {
            if (!ModelState.IsValid)
            {
                return View(accUp);
            }
            
            _context.Accounts.Update(accUp);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));

        }
        /// <summary>
        /// DeleteUser
        /// </summary>
        /// <returns>Index</returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteUser(int? AccId)
        {
            if(AccId == null || AccId <= 0)
            {
                return NotFound();
            }
            var user =  _context.Accounts.Find(AccId);
            IEnumerable<Product> list = _context.Products.Where(e => e.AccId == AccId);
            IEnumerable<Cart> dcart = _context.Carts.Where(e => e.AccId == AccId);

            if (user == null)
            {
                return NotFound();
            }
            // delete in all three Accounts,Carts
            _context.Accounts.Remove(user);
            _context.Accounts.RemoveRange(user);
            _context.Carts.RemoveRange(dcart);
            _context.SaveChanges();
            return RedirectToAction(nameof(Index));
        }
        /// <summary>
        /// Details
        /// </summary>
        /// <returns>obj</returns>
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || id < 0)
            {
                return NotFound();
            }

            var obj = await _context.Accounts.FindAsync(id);
            if (obj == null)
            {
                return NotFound();
            }
            return View(obj);
        }
        /// <summary>
        /// GetHash
        /// </summary>
        /// <returns>String hashed by MD5</returns>
        public static string GetHash(string plainText)
        {
            MD5 md5 = new MD5CryptoServiceProvider();
            // Compute hash from the bytes of text
            md5.ComputeHash(ASCIIEncoding.ASCII.GetBytes(plainText));
            // Get hash result after compute it
            byte[] result = md5.Hash;
            StringBuilder strBuilder = new StringBuilder();
            for (int i = 0; i < result.Length; i++)
            {
                strBuilder.Append(result[i].ToString("x2"));
            }

            return strBuilder.ToString();
        }
    }
}
