﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using PagedList.Core;
using ProjectCarDealer.Models;

namespace ProjectCarDealer.Controllers
{

    public class AdminProductsController : Controller
    {
        private readonly SWPDBFA21Context _context;

        public AdminProductsController(SWPDBFA21Context context)
        {
            _context = context;
           
        }

        /// <summary>
        /// Index
        /// </summary>
        /// <returns>models</returns>
        [Route("/adminproducts", Name = "adminproducts")]        
       public IActionResult Index(int? page)
        {
            string cus_name = HttpContext.Session.GetString("cus_name");
            ViewData["cus_name"] = cus_name;
            var pageNumber = page == null || page <= 0 ? 1 : page.Value;
            var pageSize = 10;
            var IsProducts = _context.Products
                .AsNoTracking()
                .Include(x => x.Cat);
            PagedList<Product> models = new PagedList<Product>(IsProducts, pageNumber, pageSize);
            ViewBag.CurrentPage = pageNumber;
            return View(models);

        }
        /// <summary>
        /// Details
        /// </summary>
        /// <returns>product</returns>
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var product = await _context.Products
                .Include(p => p.Acc)
                .Include(p => p.Cat)
                .FirstOrDefaultAsync(m => m.PodId == id);
            if (product == null)
            {
                return NotFound();
            }

            return View(product);
        }

        /// <summary>
        /// Create
        /// </summary>
        /// <returns>product</returns>
        public IActionResult Create()
        {
            ViewData["AccId"] = new SelectList(_context.Accounts, "AccId", "Username");

            ViewData["CatId"] = new SelectList(_context.Categories, "CatId", "CatName");
            return View();
        }

        /// <summary>
        /// Create
        /// </summary>
        /// <returns>product</returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("PodId,AccId,CatId,PodName,PodImage,PodDescription,VinNumber,GearType,Price,Quantity,PodStatus,DateCreated")] Product product)
        {
            if (ModelState.IsValid)
            {
                _context.Add(product);
                await _context.SaveChangesAsync();
                /*_notifyService.Success("Create Products successfully");*/
                return RedirectToAction(nameof(Index));
            }
            ViewData["AccId"] = new SelectList(_context.Accounts, "AccId", "Username", product.AccId);
            ViewData["CatId"] = new SelectList(_context.Categories, "CatId", "CatName", product.CatId);
            return View(product);
        }

        /// <summary>
        /// Edit
        /// </summary>
        /// <returns>product</returns>
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var product = await _context.Products.FindAsync(id);
            if (product == null)
            {
                return NotFound();
            }
            ViewData["AccId"] = new SelectList(_context.Accounts, "AccId", "Username", product.AccId);
            ViewData["CatId"] = new SelectList(_context.Categories, "CatId", "CatName", product.CatId);
            return View(product);
        }

        /// <summary>
        /// Edit
        /// </summary>
        /// <returns>product</returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("PodId,AccId,CatId,PodName,PodImage,PodDescription,VinNumber,GearType,Price,Quantity,PodStatus,DateCreated")] Product product)
        {
            if (id != product.PodId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(product);
                /*_notifyService.Success("Edit Products successfully");*/
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ProductExists(product.PodId))
                    {
                       /* _notifyService.Success("Edit Products Failed");*/
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["AccId"] = new SelectList(_context.Accounts, "AccId", "Username", product.AccId);
            ViewData["CatId"] = new SelectList(_context.Categories, "CatId", "CatName", product.CatId);
            return View(product);
        }

        /// <summary>
        /// Delete
        /// </summary>
        /// <returns>product</returns>
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
               /* _notifyService.Success("Delete Products successfully");*/
                return NotFound();
            }

            var product = await _context.Products
                .Include(p => p.Acc)
                .Include(p => p.Cat)
                .FirstOrDefaultAsync(m => m.PodId == id);
            if (product == null)
            {
                /*_notifyService.Success("Delete Products Failed");*/
                return NotFound();
            }

            return View(product);
        }

        /// <summary>
        /// DeleteConfirmed
        /// </summary>
        /// <returns>product</returns>
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var product = await _context.Products.FindAsync(id);
            _context.Products.Remove(product);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ProductExists(int id)
        {
            return _context.Products.Any(e => e.PodId == id);
        }
    }
}
