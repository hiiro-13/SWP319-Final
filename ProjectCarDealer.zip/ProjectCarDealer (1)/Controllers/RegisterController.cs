﻿using ProjectCarDealer.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace ProjectCarDealer.Controllers
{
    public class RegisterController : Controller
    {
        private readonly SWPDBFA21Context _context;
        public RegisterController(SWPDBFA21Context context)
        {
            this._context = context;
        }
        public IActionResult Index()
        {
            return View();
        }
        /// <summary>
        /// GetHash
        /// </summary>
        /// <returns>String hashed by MD5</returns>
        public static string GetHash(string plainText)
        {
            MD5 md5 = new MD5CryptoServiceProvider();
            // Compute hash from the bytes of text
            md5.ComputeHash(ASCIIEncoding.ASCII.GetBytes(plainText));
            // Get hash result after compute it
            byte[] result = md5.Hash;
            StringBuilder strBuilder = new StringBuilder();
            for (int i = 0; i < result.Length; i++)
            {
                strBuilder.Append(result[i].ToString("x2"));
            }

            return strBuilder.ToString();
        }
        /// <summary>
        /// AddNew
        /// </summary>
        /// <returns>Index</returns>
        [HttpPost]
        public ActionResult AddNew(RegisterModelView us)
        {
            string inputName = us.name;
            string inputEmail = us.email;
            string inputPass = us.pass;
            string gender = us.Gender;
            string inputConfirmPass = us.confirmPassword;
            if (inputName == null || inputPass == null || inputConfirmPass == null || inputEmail == null)
            {
                return View("Index");
            }
            else
            {
                var obj = _context.Accounts.Where(x => x.Username == inputName).FirstOrDefault();
                if (obj != null)
                {
                    ViewBag.RegisterFailMessage = "Username is already exits.";
                    return View("Index");
                }
                else
                {
                    if (inputPass.Equals(inputConfirmPass) == true)
                    {
                        Account acc = new Account()
                        {
                            Username = inputName,
                            Userpassword = GetHash(inputPass),
                            Email = inputEmail,
                            Firstname = us.firstname,
                            Lastname = us.lastname,
                            Birthday = us.birthday,
                            Phonenumber = us.phone,
                            Address = us.address,
                            DateCreated = DateTime.Today,
                            Gender = us.Gender,
                            AccStatus = true,
                            IsSeller = true,
                            IsCustomer = true,    
                            Valid = true
                        };
                        _context.Add(acc);
                        _context.SaveChanges();
                        return RedirectToAction("Index", "Login");
                    }
                    else
                    {
                        ViewBag.DoesntMatchingMessage = "ConfirmPassword doesn't matching with PassWord";
                        return View("Index");
                    }
                   
                }
            }

        }
    }
}
