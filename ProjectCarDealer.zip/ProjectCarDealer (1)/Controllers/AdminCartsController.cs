﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ProjectCarDealer.Models;

namespace ProjectCarDealer.Controllers
{

    public class AdminCartsController : Controller
    {
        private readonly SWPDBFA21Context _context;

        public AdminCartsController(SWPDBFA21Context context)
        {
            _context = context;
        }

        /// <summary>
        /// Index
        /// </summary>
        /// <returns>List of carts</returns>
        public async Task<IActionResult> Index()
        {
            string cus_name = HttpContext.Session.GetString("cus_name");
            ViewData["cus_name"] = cus_name;
            var SWPDBFA21Context = _context.Carts.Include(c => c.Acc).Include(c => c.Pod);
            return View(await SWPDBFA21Context.ToListAsync());
        }

        /// <summary>
        /// Details
        /// </summary>
        /// <returns>cart details</returns>
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            //
            var cart = await _context.Carts
                .Include(c => c.Acc)
                .Include(c => c.Pod)
                .FirstOrDefaultAsync(m => m.CartId == id);
            if (cart == null)
            {
                return NotFound();
            }

            return View(cart);
        }

        /// <summary>
        /// Create
        /// </summary>
        /// <returns>View</returns>
        public IActionResult Create()
        {
            ViewData["AccId"] = new SelectList(_context.Accounts, "AccId", "Address");
            ViewData["PodId"] = new SelectList(_context.Products, "PodId", "GearType");
            return View();
        }

        /// <summary>
        /// Create
        /// </summary>
        /// <returns>create new cart</returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("CartId,AccId,PodId,DateCreated")] Cart cart)
        {
            if (ModelState.IsValid)
            {
                _context.Add(cart);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["AccId"] = new SelectList(_context.Accounts, "AccId", "Address", cart.AccId);
            ViewData["PodId"] = new SelectList(_context.Products, "PodId", "GearType", cart.PodId);
            return View(cart);
        }

        /// <summary>
        /// Edit
        /// </summary>
        /// <returns>View</returns>
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var cart = await _context.Carts.FindAsync(id);
            if (cart == null)
            {
                return NotFound();
            }
            ViewData["AccId"] = new SelectList(_context.Accounts, "AccId", "Address", cart.AccId);
            ViewData["PodId"] = new SelectList(_context.Products, "PodId", "GearType", cart.PodId);
            return View(cart);
        }

        /// <summary>
        /// Edit
        /// </summary>
        /// <returns>Edit cart</returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("CartId,AccId,PodId,DateCreated,Quantity")] Cart cart)
        {
            if (id != cart.CartId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(cart);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CartExists(cart.CartId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["AccId"] = new SelectList(_context.Accounts, "AccId", "Address", cart.AccId);
            ViewData["PodId"] = new SelectList(_context.Products, "PodId", "GearType", cart.PodId);
            return View(cart);
        }

        /// <summary>
        /// Delete
        /// </summary>
        /// <returns>View</returns>
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var cart = await _context.Carts
                .Include(c => c.Acc)
                .Include(c => c.Pod)
                .FirstOrDefaultAsync(m => m.CartId == id);
            if (cart == null)
            {
                return NotFound();
            }

            return View(cart);
        }

        /// <summary>
        /// Delete
        /// </summary>
        /// <returns>Delete cart</returns>
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var cart = await _context.Carts.FindAsync(id);
            _context.Carts.Remove(cart);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CartExists(int id)
        {
            return _context.Carts.Any(e => e.CartId == id);
        }
    }
}
