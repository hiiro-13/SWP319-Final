﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PagedList.Core;
using ProjectCarDealer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProjectCarDealer.Controllers
{
    public class SearchController : Controller
    {
        private readonly SWPDBFA21Context _context;
        public SearchController(SWPDBFA21Context context)
        {
            _context = context;
           
        }
        /// <summary>
        ///[Route("index", Name = "index")]
        ///[Route("")]
        ///[Route("~/")]
        /// </summary>
        /// <returns>List accounts</returns>
        public IActionResult Index()
        {
            return View();
        }
        /// <summary>
        /// Search
        /// </summary>
        /// <returns>Index</returns>
        public IActionResult Search(int? page)
        {
            string cus_name = HttpContext.Session.GetString("cus_name");
            ViewData["cus_name"] = cus_name;
            var pageNumber = page == null || page <= 0 ? 1 : page.Value;
            // number of products in the page
            var pageSize = 9;
            // search by keyword of Product
            var keyword = Request.Query["keyword"].ToString();
            var products = _context.Products.Where(p => p.PodName.Contains(keyword));
            PagedList<Product> models = new PagedList<Product>(products, pageNumber, pageSize);
            ViewData["keyword"] = keyword;
            ViewBag.CurrentPage = pageNumber;
            ViewBag.LastPage = models.PageCount;
            return View("Index", models);
        }
    }
}
