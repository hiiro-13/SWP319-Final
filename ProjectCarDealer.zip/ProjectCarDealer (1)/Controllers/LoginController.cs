﻿using Microsoft.AspNetCore.Mvc;
using System.Linq;
using Microsoft.AspNetCore.Http;
using System.Security.Cryptography;
using System.Text;
using NToastNotify;
using DNTCaptcha.Core;
using System;
using Microsoft.Extensions.Options;
using ProjectCarDealer.Models;

namespace ProjectCarDealer.Controllers
{

    public class LoginController : Controller
    {
        private readonly SWPDBFA21Context _context;
        private readonly IToastNotification _notyf;
        private readonly IDNTCaptchaValidatorService _dNTCaptchaValidatorService;
        private readonly DNTCaptchaOptions _dNTCaptchaOptions;
        public LoginController(SWPDBFA21Context context, IToastNotification notyf, IDNTCaptchaValidatorService dNTCaptchaValidatorService, IOptions<DNTCaptchaOptions> dNTCaptchaOptions)
        {
            this._context = context;
            this._notyf = notyf;
            this._dNTCaptchaValidatorService = dNTCaptchaValidatorService;
            this._dNTCaptchaOptions = dNTCaptchaOptions == null ? throw new ArgumentException(nameof(dNTCaptchaOptions)) : dNTCaptchaOptions.Value;

        }
        /// <summary>
        /// Index Login
        /// </summary>
        /// <returns>Index Home</returns>
        [HttpGet]
        public IActionResult Index()
        {
           
            string cus_name = HttpContext.Session.GetString("cus_name");
            
            if (cus_name != null)
            {
                return RedirectToAction("Index", "Home");
            }
            else
            {
                cus_name = Request.Cookies["cus_name"];
                if (cus_name != null)
                {
                    HttpContext.Session.SetString("cus_name", cus_name);
                    return RedirectToAction("Index", "Home");
                }
            }
            return View();
        }
        /// <summary>
        ///GetHash
        /// </summary>
        /// <returns>Index Home</returns>
        public static string GetHash(string plainText)
        {
            MD5 md5 = new MD5CryptoServiceProvider();
            // Compute hash from the bytes of text
            md5.ComputeHash(ASCIIEncoding.ASCII.GetBytes(plainText));
            // Get hash result after compute it
            byte[] result = md5.Hash;
            StringBuilder strBuilder = new StringBuilder();
            for (int i = 0; i < result.Length; i++)
            {
                strBuilder.Append(result[i].ToString("x2"));
            }

            return strBuilder.ToString();
        }
         /// <summary>
        ///CheckLogin
        /// </summary>
        /// <returns>Index Home</returns>
        [HttpPost]
        public ActionResult CheckLogin(ProjectCarDealer.Models.LoginModelView us, bool RememberMe)
        {
            string inputName = us.name;
            string inputPass = us.pass;
            

            var customerDetails = _context.Accounts.Where(x => x.Username == inputName && x.Userpassword == GetHash(inputPass)).FirstOrDefault();
            if (ModelState.IsValid) 
            {
                
                if (customerDetails == null)
                {
                    this._notyf.AddErrorToastMessage("Wrong UserName or Password");
                    ViewBag.LoginFailMessage = "Wrong UserName or Password";
                    return View("Index");
                }
                if (!_dNTCaptchaValidatorService.HasRequestValidCaptchaEntry(Language.English, DisplayMode.ShowDigits))
                {
                    _notyf.AddErrorToastMessage("Please Enter Valid Captcha");
                    return View("Index");
                }
                else
                {
                    HttpContext.Session.SetString("cus_name", customerDetails.Username);

                    if (RememberMe)
                    {
                        CookieOptions options = new CookieOptions();
                        options.Expires = System.DateTime.Now.AddHours(1.5);
                        string CookieValue = inputName;
                        Response.Cookies.Append("cus_name", CookieValue, options);
                    }
                    var checkRole = customerDetails.IsAdmin;
                    if (checkRole)
                    {
                        return RedirectToAction("Index", "Admin");
                    }
                    return RedirectToAction("Index");

                }
            }
            return View("Index");
        }
        /// <summary>
        ///LogOut
        /// </summary>
        /// <returns>Index Home</returns>
        public ActionResult LogOut()
        {
            HttpContext.Session.Remove("cus_name");
            Response.Cookies.Delete("cus_name");
            return RedirectToAction("Index", "Home");
        }

    }
}