﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using NToastNotify;
using ProjectCarDealer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProjectCarDealer.Controllers
{

    public class Checkout : Controller
    {
        private readonly SWPDBFA21Context _context;
        public decimal exchangeRateUSD = 23000;
        private readonly IToastNotification _notyf;
        private readonly ILogger<Checkout> _logger;

        /// <summary>
        ///Checkout
        /// </summary>
        /// <returns>Index</returns>
        public Checkout(SWPDBFA21Context context, IToastNotification notyf, ILogger<Checkout> logger)
        {
            _logger = logger;
            _context = context;
            this._notyf = notyf;

        }
        // Cart's json string key
        public const string CARTKEY = "GioHang";

        // Get cart from Session (list of CartItem)
        List<Cart> GetCartItems()
        {

            var session = HttpContext.Session;
            string jsoncart = session.GetString(CARTKEY);
            if (jsoncart != null)
            {
                return JsonConvert.DeserializeObject<List<Cart>>(jsoncart);
            }
            return new List<Cart>();


        }
        // Remove cart from session
        void ClearCart()
        {
            var session = HttpContext.Session;
            session.Remove(CARTKEY);
        }

        // Save Cart (List of CartItem) in session
        void SaveCartSession(List<Cart> ls)
        {
            var session = HttpContext.Session;
            string jsoncart = JsonConvert.SerializeObject(ls);
            session.SetString(CARTKEY, jsoncart);
        }

        /// <summary>
        ///Index
        /// </summary>
        /// <returns>model</returns>
        [Route("cart/Checkout", Name = "Checkout")]
        public IActionResult Index(string returnUrl = null)
        {
            //Take the cart to process
            string cus_name = HttpContext.Session.GetString("cus_name");
            ViewData["cus_name"] = cus_name;
            var cart = GetCartItems();
            var taikhoanID = HttpContext.Session.GetString("cus_name");
            var total = GetCartItems().Sum(p => p.Pod.Price * p.Quantity);
            var sumTotal = Math.Round(total / exchangeRateUSD, 2);
            BuyingProducts model = new BuyingProducts();
            // check taikhoanID null
            if (taikhoanID != null)
            {
                var khachhang = _context.Accounts.AsNoTracking().SingleOrDefault(x => x.Username == (taikhoanID));
                model.CustomerId = khachhang.AccId;
                model.FirstName = khachhang.Firstname;
                model.LastName = khachhang.Lastname;
                model.Email = khachhang.Email;
                model.Phone = khachhang.Phonenumber;
                model.Address = khachhang.Address;

            }
            ViewBag.GioHang = cart;
            return View(model);
        }
        
        /// <summary>
        ///checkout
        /// </summary>
        /// <returns>model</returns>
        [HttpPost]
        [Route("Cart/Checkout", Name = "Checkout")]
        public IActionResult checkout(BuyingProducts Buying)
        {
            //Take the cart to process
            var cart = GetCartItems();
            var cus_name = HttpContext.Session.GetString("cus_name");
            var taikhoanID = HttpContext.Session.GetString("cus_name");
            BuyingProducts model = new BuyingProducts();
            // check taikhoanID null
            if (taikhoanID != null)
            {
                var khachhang = _context.Accounts.AsNoTracking().SingleOrDefault(x => x.Username == (taikhoanID));
                model.CustomerId = khachhang.AccId;
                model.FirstName = khachhang.Firstname;
                model.LastName = khachhang.Lastname;
                model.Email = khachhang.Email;
                model.Phone = khachhang.Phonenumber;
                model.Address = khachhang.Address;
               // model.PodId = (Product)khachhang.Products.;

                _context.Update(khachhang);
                _context.SaveChanges();
            }
            //Order creation
            if (ModelState.IsValid)
            {
                OrderProduct donhang = new OrderProduct();
                donhang.AccId = model.CustomerId;
                donhang.PodId = model.Podid;
                donhang.Address = model.Address;
                donhang.OrdStatus = true;//don hang moi
                donhang.Phonenumber = model.Phone;
                
                var TotalMoney = Convert.ToInt32(cart.Sum(p => p.Pod.Price * p.Quantity));
                _context.Add(donhang);
                _context.SaveChanges();
                //Create order list
                foreach (var item in cart)
                {
                    OrderDetail orderdetails = new OrderDetail();
                    
                    orderdetails.Quantity = item.Quantity;
                    orderdetails.TotalMoney = TotalMoney;
                    orderdetails.Price = item.Pod.Price;
                    _context.Add(orderdetails);
                 
                }
                //Save order
                _context.SaveChanges();
                //clear cart
                HttpContext.Session.Remove(CARTKEY);
                _notyf.AddSuccessToastMessage("Check out successfully");
                // Update customer information
                return RedirectToAction("SuccessBuying");
            }
            ViewBag.CARTKEY = cart;
            return View(model);
        }

        /// <summary>
        ///Success
        /// </summary>
        /// <returns>Index</returns>
        [Route("Checkout/SuccessBuying", Name = "SuccessBuying")]
        public IActionResult Success()
        {
            try
            {
                var cus_name = HttpContext.Session.GetString("cus_name");
                var taikhoanID = HttpContext.Session.GetString("cus_name");
                if (string.IsNullOrEmpty(taikhoanID))
                {
                    return RedirectToAction("Index", "Login", new {returnUrl="/SuccessBuying" });
                }
                var khachhang = _context.Accounts.AsNoTracking().SingleOrDefault(x => x.Username == (taikhoanID));
                var donhang = _context.OrderProducts.Where(x => x.AccId == Convert.ToInt32(taikhoanID));
                BuyingProductsSuccess successVM = new BuyingProductsSuccess();
                
                successVM.FirstName = khachhang.Firstname;
                successVM.LastName = khachhang.Lastname;
                successVM.Email = khachhang.Email;
                successVM.Address = khachhang.Address;
                successVM.Phone = khachhang.Phonenumber;

                /*   model.CustomerId = khachhang.AccId;
                   model.FirstName = khachhang.Firstname;
                   model.LastName = khachhang.Lastname;
                   model.Email = khachhang.Email;
                   model.Phone = khachhang.Phonenumber;
                   */

            
                return RedirectToAction("Index", "Login");
               
            }
            catch
            {
                _notyf.AddWarningToastMessage("Check out Failed");
                return RedirectToAction("Index","Login");
            }
        }
    }
}
