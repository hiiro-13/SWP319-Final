﻿using BraintreeHttp;
using ProjectCarDealer.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using PagedList.Core;
using PayPal.Core;
using PayPal.v1.Payments;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using NToastNotify;

namespace DemoCarDealer.Controllers
{
    [Route("/products", Name = "products")]
    public class ProductController : Controller
    {
        private readonly SWPDBFA21Context _context;
        private readonly ILogger<ProductController> _logger;
        private readonly string _clientId;
        private readonly string _secretKey;
        private readonly IToastNotification _notyf;
        //exchange rate from VND to USD
        public decimal exchangeRateUSD = 23000;
        /// <summary>
        /// ProductController
        /// </summary>
        /// <returns>Index</returns>
        public ProductController(SWPDBFA21Context context, IToastNotification notyf, ILogger<ProductController> logger, IConfiguration config)
        {
            _logger = logger;
            _context = context;
            _clientId = config["PaypalSettings:ClientId"];
            _secretKey = config["PaypalSettings:SecretKey"];
            this._notyf = notyf;

        }
        /// <summary>
        /// Index
        /// </summary>
        /// <returns>models</returns>
        public IActionResult Index(int? page)
        {
            string cus_name = HttpContext.Session.GetString("cus_name");
            ViewData["cus_name"] = cus_name;
            var pageNumber = page == null || page <= 0 ? 1 : page.Value;
            var pageSize = 9;
            var IsProducts = _context.Products
                .AsNoTracking()
                .Include(x => x.Cat);
            PagedList<Product> models = new PagedList<Product>(IsProducts, pageNumber, pageSize);
            ViewBag.CurrentPage = pageNumber;
            return View(models);

        }
       

        /// <summary>
        /// AddToCart
        /// </summary>
        /// <returns>models</returns>
        [Route("addcart/{productid:int}", Name = "addcart")]
        public IActionResult AddToCart([FromRoute] int productid)
        {

            var product = _context.Products
                            .Where(p => p.PodId == productid)
                            .FirstOrDefault();
            if (product == null)
                return NotFound("Không có sản phẩm");

            // Handling put into Cart...
            var cart = GetCartItems();
            var cartitem = cart.Find(p => p.Pod.PodId == productid);
            if (cartitem != null)
            {
                // Already exist, increase by 1
                cartitem.Quantity++;
            }
            else
            {
                //  Add new
                cart.Add(new Cart() { Quantity = 1, Pod = product });
            }
            // Save cart to Session
            SaveCartSession(cart);
            // Go to Cart display page
            return RedirectToAction(nameof(Cart));
        }

        /// <summary>
        /// RemoveCart
        /// </summary>
        /// <returns>Cart</returns>
        [Route("/removecart/{productid:int}", Name = "removecart")]
        public IActionResult RemoveCart([FromRoute] int productid)
        {
            var cart = GetCartItems();
            var cartitem = cart.Find(p => p.Pod.PodId == productid);
            if (cartitem != null)
            {
                // Already exist, increase by 1
                cart.Remove(cartitem);
            }

            SaveCartSession(cart);
            return RedirectToAction(nameof(Cart));
        }

        /// <summary>
        /// UpdateCart
        /// </summary>
        /// <returns>Ajax to call</returns>
        [Route("/updatecart/", Name = "updatecart")]
        [HttpPost]
        public IActionResult UpdateCart([FromForm] int productid, [FromForm] int quantity)
        {
            // Cart update changes quantity ...
            var cart = GetCartItems();
            var cartitem = cart.Find(p => p.Pod.PodId == productid);
            if (cartitem != null)
            {
                // Already exist, increase by 1
                cartitem.Quantity = quantity;
            }
            SaveCartSession(cart);
            // Returns a success code (no content - just for Ajax to call)
            return Ok();
        }
       

        /// <summary>
        /// Cart
        /// </summary>
        /// <returns>product</returns>
        [Route("/cart", Name = "cart")]
        public IActionResult Cart()
        {
            string cus_name = HttpContext.Session.GetString("cus_name");
            ViewData["cus_name"] = cus_name;
            return View(GetCartItems());
        }
        /// <summary>
        /// Details
        /// </summary>
        /// <returns>product</returns>
        [Route("/Details", Name = "details")]
        public async Task<IActionResult> Details(int? id)
        {
            string cus_name = HttpContext.Session.GetString("cus_name");
            ViewData["cus_name"] = cus_name;
            if (id == null)
            {
                return NotFound();
            }

            var product = await _context.Products
                .Include(p => p.Acc)
                .Include(p => p.Cat)
                .FirstOrDefaultAsync(m => m.PodId == id);
            if (product == null)
            {
                return NotFound();
            }

            return View(product);
        }
       
        // Cart's json string key
        public const string CARTKEY = "GioHang";

        // Get cart from Session (list of CartItem)
        List<Cart> GetCartItems()
        {

            var session = HttpContext.Session;
            string jsoncart = session.GetString(CARTKEY);
            if (jsoncart != null)
            {
                return JsonConvert.DeserializeObject<List<Cart>>(jsoncart);
            }
            return new List<Cart>();


        }
        // Remove cart from session
        void ClearCart()
        {
            var session = HttpContext.Session;
            session.Remove(CARTKEY);
        }

        // Save Cart (List of CartItem) in session
        void SaveCartSession(List<Cart> ls)
        {
            var session = HttpContext.Session;
            string jsoncart = JsonConvert.SerializeObject(ls);
            session.SetString(CARTKEY, jsoncart);
        }
        /// <summary>
        /// make product payment checkout with paypal page
        /// </summary>
        /// <returns>paypalRedirectUrl</returns>
        [Route("/PaypalCheckout", Name = "PaypalCheckout")]
        public async Task<IActionResult> PaypalCheckout()
        {
            // Processing when ordering
            var environment = new SandboxEnvironment(_clientId, _secretKey);
            var client = new PayPalHttpClient(environment);

            #region Create Paypal Order
            var itemList = new ItemList()
            {
                Items = new List<Item>()
            };
            var total = GetCartItems().Sum(p => p.Pod.Price * p.Quantity);
            var sumTotal = Math.Round(total / exchangeRateUSD, 2);

            foreach (var item in GetCartItems())
            {
                decimal podPrice = item.Pod.Price;
                podPrice = Math.Round(podPrice / exchangeRateUSD, 2);
                itemList.Items.Add(new Item()
                {
                    Name = item.Pod.PodName,
                    Currency = "USD",
                    Price = podPrice.ToString(),
                    Quantity = item.Quantity.ToString(),
                    Sku = "sku",
                    Tax = "0"
                });
            }
            #endregion

            var paypalOrderId = DateTime.Now.Ticks;
            var hostname = $"{HttpContext.Request.Scheme}://{HttpContext.Request.Host}";
            var payment = new Payment()
            {
                Intent = "sale",
                Transactions = new List<Transaction>()
                {
                    new Transaction()
                    {
                        Amount = new Amount()
                        {
                            Total = sumTotal.ToString(),
                            Currency = "USD",
                            Details = new AmountDetails
                            {
                                Tax = "0",
                                Shipping = "0",
                                Subtotal = sumTotal.ToString()
                            }
                        },
                        ItemList = itemList,
                        Description = $"Invoice #{paypalOrderId}",
                        InvoiceNumber = paypalOrderId.ToString()
                    }
                },
                RedirectUrls = new RedirectUrls()
                {
                    CancelUrl = $"{ hostname }/CheckoutFail",
                    ReturnUrl = $"{ hostname }/CheckoutSuccess"
                },
                Payer = new Payer()
                {
                    PaymentMethod = "paypal"
                }
            };
            PaymentCreateRequest request = new PaymentCreateRequest();
            request.RequestBody(payment);
            try
            {
                var response = await client.Execute(request);
                var statusCode = response.StatusCode;
                Payment result = response.Result<Payment>();

                var links = result.Links.GetEnumerator();
                string paypalRedirectUrl = null;
                while (links.MoveNext())
                {
                    LinkDescriptionObject lnk = links.Current;
                    if (lnk.Rel.ToLower().Trim().Equals("approval_url"))
                    {
                        //saving the payapalredirect URL to which user will be redirected for payment  
                        paypalRedirectUrl = lnk.Href;
                    }
                }

                return Redirect(paypalRedirectUrl);
            }
            catch (HttpException httpException)
            {
                var statusCode = httpException.StatusCode;
                var debugId = httpException.Headers.GetValues("PayPal-Debug-Id").FirstOrDefault();

                //Process when Checkout with Paypal fails
                return Redirect("/CheckoutFail");
            }
        }
        /// <summary>
        /// CheckoutFail
        /// </summary>
        /// <returns>View</returns>
        [Route("/CheckoutFail", Name = "CheckoutFail")]
        public IActionResult CheckoutFail()
        {
            HttpContext.Session.GetString("cus_name");
            ClearCart();
            _notyf.AddErrorToastMessage("Check out Failed");
            return RedirectToAction("Index", "Product");
        }
        /// <summary>
        /// CheckoutSuccess
        /// </summary>
        /// <returns>Index</returns>
        [Route("/CheckoutSuccess", Name = "CheckoutSuccess")]
        public IActionResult CheckoutSuccess(OrderProduct orderProduct)
        {

            HttpContext.Session.GetString("cus_name");
            ClearCart();
            _notyf.AddSuccessToastMessage("Check out successfully");
            return RedirectToAction("Index","Product");
        }
       
        
    }


}
