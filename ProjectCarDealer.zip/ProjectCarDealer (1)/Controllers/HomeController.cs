﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProjectCarDealer.Controllers
{
    public class HomeController : Controller
    {   
        /// <summary>
        ///Index
        /// </summary>
        /// <returns>Index Home</returns>
        public IActionResult Index()
        {
            if (HttpContext.Session.GetString("cus_name") == null)
            {
                return View();
            }
            else
            {
                ViewData["GetSession"] = HttpContext.Session.GetString("cus_name");
                return View();
            }
        }
    }
}
