﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ProjectCarDealer.Models;

namespace ProjectCarDealer.Controllers
{
    
    public class AdminAccController : Controller
    {
        private readonly SWPDBFA21Context _context;
        
        /// <summary>
        /// AdminAccController
        /// </summary>
        /// <returns></returns>
        public AdminAccController(SWPDBFA21Context context)
        {
            _context = context;
        }

        
        /// <summary>
        /// Index
        /// </summary>
        /// <returns>List accounts</returns>
        public async Task<IActionResult> Index()
        {
            string cus_name = HttpContext.Session.GetString("cus_name");
            ViewData["cus_name"] = cus_name;
            return View(await _context.Accounts.ToListAsync());
        }
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var account = await _context.Accounts
                .FirstOrDefaultAsync(m => m.AccId == id);
            if (account == null)
            {
                return NotFound();
            }

            return View(account);
        }

        /// <summary>
        /// Create
        /// </summary>
        /// <returns>view</returns>
        public IActionResult Create()
        {
            return View();
        }

        /// <summary>
        /// Create
        /// </summary>
        /// <returns>new account</returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("AccId,Gender,Birthday,Username,Userpassword,Email,AccAvt,Phonenumber,Firstname,Lastname,Address,DateCreated,AccStatus,IsAdmin,IsSeller,IsCustomer")] Account account)
        {
            if (ModelState.IsValid)
            {
                _context.Add(account);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(account);
        }
        
        /// <summary>
        /// Edit
        /// </summary>
        /// <returns>View</returns>
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var account = await _context.Accounts.FindAsync(id);
            if (account == null)
            {
                return NotFound();
            }
            return View(account);
        }

        /// <summary>
        /// Edit
        /// </summary>
        /// <returns>Edit account</returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("AccId,Gender,Birthday,Username,Userpassword,Email,AccAvt,Phonenumber,Firstname,Lastname,Address,DateCreated,AccStatus,IsAdmin,IsSeller,IsCustomer")] Account account)
        {
            if (id != account.AccId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(account);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!AccountExists(account.AccId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(account);
        }
        
        /// <summary>
        /// Delete
        /// </summary>
        /// <returns>Delete account</returns>
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var account = await _context.Accounts
                .FirstOrDefaultAsync(m => m.AccId == id);
            if (account == null)
            {
                return NotFound();
            }

            return View(account);
        }

        private bool AccountExists(int id)
        {
            return _context.Accounts.Any(e => e.AccId == id);
        }
    }
}