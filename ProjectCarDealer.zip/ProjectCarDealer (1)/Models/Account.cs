﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

#nullable disable

namespace ProjectCarDealer.Models
{
    public partial class Account
    {
        
        public Account()
        {
            Carts = new HashSet<Cart>();
            OrderProducts = new HashSet<OrderProduct>();
            Products = new HashSet<Product>();
        }
        //AccId Account
        public int AccId { get; set; }
        //Gender Account
        public string Gender { get; set; }
        //Birthday Account
        [DisplayName("Your Birthday")]
        public DateTime Birthday { get; set; }
        //Username Account
        public string Username { get; set; }
        //Userpassword Account
        public string Userpassword { get; set; }
        //Email Account
        [Required(ErrorMessage = "Email cannot be blank")]
        public string Email { get; set; }
        //AccAvt Account
        [DisplayName("Your Avatar")]
        public string AccAvt { get; set; }
        //Phonenumber Account
        [Required(ErrorMessage = "Phone cannot be blank")]
        [StringLength(15, ErrorMessage = "Số điện thoại phải bao gồm 10 chữ số", MinimumLength = 10)]
        public string Phonenumber { get; set; }
        //Firstname Account
        [Required(ErrorMessage = "First cannot be blank")]
        public string Firstname { get; set; }
        //Lastname Account
        [Required(ErrorMessage = "Last cannot be blank")]
        public string Lastname { get; set; }
        //Address Account
        [Required(ErrorMessage = "Address cannot be blank")]
        public string Address { get; set; }
        //DateCreated Account
        public DateTime DateCreated { get; set; }
        //AccStatus Account
        public bool AccStatus { get; set; }
        //IsAdmin Account
        public bool IsAdmin { get; set; }
        //IsSeller Account
        public bool IsSeller { get; set; }
        //IsCustomer Account
        public bool IsCustomer { get; set; }
        //Valid Account
        public bool Valid { get; set; }
        //ImageFile Account
        [NotMapped]
        public IFormFile ImageFile { get; set; }

        //Get list Cart
        public virtual ICollection<Cart> Carts { get; set; }
        //Get list OrderProduct
        public virtual ICollection<OrderProduct> OrderProducts { get; set; }
        //Get list Product
        public virtual ICollection<Product> Products { get; set; }
    }
}
