﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ProjectCarDealer.Models
{
    public class ChangePassModelView
    {
        //pass RegisterModelView
        [DisplayName("Password")]
        [Required(ErrorMessage = "Password cannot be blank")]
        [DataType(DataType.Password)]
        public string pass { get; set; }
        //newPass ChangePassModelView
        [DisplayName("New Password")]
        [Required(ErrorMessage = "New Password cannot be blank")]
        [DataType(DataType.Password)]
        [StringLength(15, ErrorMessage = "Mật khẩu phải có ít nhất 6 ký tự", MinimumLength = 6)]
        public string newPass { get; set; }
        //confirmPass ChangePassModelView
        [DisplayName("Confirm Password")]
        [Required(ErrorMessage = "Confirm Password cannot be blank")]
        [DataType(DataType.Password)]
        [Compare("newPass",ErrorMessage ="Confrim password doesn't matching with new Password")]
        public string confirmPass { get; set; }
    }
}
