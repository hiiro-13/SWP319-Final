﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

#nullable disable

namespace ProjectCarDealer.Models
{
    public class Cart
    {   
        //CartId Account
        public int CartId { get; set; }
        //AccId Account
        public int AccId { get; set; }
        //PodId Product
        public int PodId { get; set; }
        //DateCreated Account
        public DateTime? DateCreated { get; set; }
        //Quantity Account
        public int Quantity { get; set; }
        //Get list Account
        public virtual Account Acc { get; set; }
        //Get list Product
        public virtual Product Pod { get; set; }

    }
}
  
    
   


