﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ProjectCarDealer.Models
{
    public class OrderDetail
    {
        //OrderDetailID OrderDetail
        [Key]
        public int OrderDetailID { get; set; }
        //OrdID OrderDetail
        public int OrdID { get; set; }
        //Quantity OrderDetail
        public int Quantity { get; set; }
        //TotalMoney OrderDetail
        public decimal TotalMoney { get; set; }
        //Price OrderDetail
        public decimal Price { get; set; }
        //DateCreated OrderDetail
        public DateTime DateCreated { get; set; }
        //Get list OrderProduct
        [ForeignKey("OrdID")]
        public virtual OrderProduct OrdId { get; set; }



    }
}
