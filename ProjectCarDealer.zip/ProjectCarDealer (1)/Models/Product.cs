﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ProjectCarDealer.Models
{
    public partial class Product
    {
        public Product()
        {
            Carts = new HashSet<Cart>();
            OrderProducts = new HashSet<OrderProduct>();
        }
        //PodId Product
        public int PodId { get; set; }
        //AccId Account
        public int AccId { get; set; }
        //CatId Category
        public int CatId { get; set; }
        //PodName Product
        public string PodName { get; set; }
        //PodImage Product
        public string PodImage { get; set; }
        //PodDescription Product
        public string PodDescription { get; set; }
        //VinNumber Category
        public string VinNumber { get; set; }
        //GearType Category
        public string GearType { get; set; }
        //Price Category
        public decimal Price { get; set; }
        //Quantity Category
        public byte Quantity { get; set; }
        //PodStatus Product
        public bool PodStatus { get; set; }
        //DateCreated Category
        public DateTime DateCreated { get; set; }
        //Valid Category
        public bool Valid { get; set; }
        //Get list Account
        public virtual Account Acc { get; set; }
        //Get list Category
        public virtual Category Cat { get; set; }
        //Get list Cart
        public virtual ICollection<Cart> Carts { get; set; }
        //Get list OrderProduct
        public virtual ICollection<OrderProduct> OrderProducts { get; set; }
    }
}
