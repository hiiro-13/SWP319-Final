﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ProjectCarDealer.Models
{
    public class ForgotPassModelView
    {   
        //name RegisterModelView
        [DisplayName("User Name")]
        [Required(ErrorMessage = "UserName cannot be blank")]
        public string name { get; set; }

        //email RegisterModelView
        [DisplayName("Email")]
        [EmailAddress]
        [Required(ErrorMessage = "Email cannot be blank")]
        public string email { get; set; }

        
    }
}
