﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProjectCarDealer.Models
{
    public class Gallery
    {
        //ID Gallery
        public int ID { get; set; }
        //ImagePath Gallery
        public string ImagePath { get; set; }
    }
}
