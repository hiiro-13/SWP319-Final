﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ProjectCarDealer.Models
{
    public class BuyingProductsSuccess
    {
        public BuyingProductsSuccess()
        {
          
            OrderProducts = new HashSet<OrderProduct>();

        }
        //CustomerId BuyingProductsSuccess
        public int CustomerId { get; set; }
        //FirstName Account
        [Required(ErrorMessage = "First name cannot be null")]
        public string FirstName { get; set; }
        //LastName Account
        [Required(ErrorMessage = "Last name cannot be null")]
        public string LastName { get; set; }
        //Email Account
        public string Email { get; set; }
        //Phone Account
        [Required(ErrorMessage = "Phone number cannot be null")]
        public string Phone { get; set; }
        //Address Account
        [Required(ErrorMessage = "Address cannot be null")]
        public string Address { get; set; }
        //Get list OrderProduct
        public virtual ICollection<OrderProduct> OrderProducts { get; set; }
    }
}
