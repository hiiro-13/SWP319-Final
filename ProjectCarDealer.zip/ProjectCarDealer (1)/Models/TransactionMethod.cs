﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ProjectCarDealer.Models
{
    public partial class TransactionMethod
    {
        public TransactionMethod()
        {
            OrderProducts = new HashSet<OrderProduct>();
        }
        //TraId OrderProduct
        public int TraId { get; set; }
        //TraStatus TransactionMethod
        public bool TraStatus { get; set; }
        //Amount TransactionMethod
        public decimal Amount { get; set; }
        //Payment TransactionMethod
        public string Payment { get; set; }
        //PaymentInfo TransactionMethod
        public string PaymentInfo { get; set; }
        //Message TransactionMethod
        public string Message { get; set; }
        //Security TransactionMethod
        public string Security { get; set; }
        //DateCreated TransactionMethod
        public DateTime DateCreated { get; set; }
        //Get list OrderProduct
        public virtual ICollection<OrderProduct> OrderProducts { get; set; }
    }
}
