﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ProjectCarDealer.Models
{
    public class LoginModelView
    {   
        //id RegisterModelView
        public int id { get; set; }
        //name RegisterModelView
        [DisplayName("User Name")]
        [Required(ErrorMessage = "UserName cannot be blank")]
        public string name { get; set; }

        //pass RegisterModelView
        [DisplayName("Password")]
        [Required(ErrorMessage = "Password cannot be blank")]
        [DataType(DataType.Password)]
        public string pass { get; set; }
       

    }
}
