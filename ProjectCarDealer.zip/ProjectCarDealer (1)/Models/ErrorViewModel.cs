using System;

namespace ProjectCarDealer.Models
{
    public class ErrorViewModel
    {   
        //RequestId ErrorViewModel
        public string RequestId { get; set; }

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }
}
