﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ProjectCarDealer.Models
{
    public partial class OrderProduct
    {   
        //OrdId OrderDetail
        public int OrdId { get; set; }
        //AccId Account
        public int AccId { get; set; }
        //PodId Product
        public int PodId { get; set; }
        //TraId TransactionMethod
        public int TraId { get; set; }
        //Quantity Product
        public int Quantity { get; set; }
        //OrdStatus Order
        public bool OrdStatus { get; set; }
        //DateCreated Product
        public DateTime DateCreated { get; set; }
        //Phonenumber Account
        public string Phonenumber { get; set; }
        //Address Account
        public string Address { get; set; }
         //Get list Account
        public virtual Account Acc { get; set; }
         //Get list Product
        public virtual Product Pod { get; set; }
         //Get list TransactionMethod
        public virtual TransactionMethod Tra { get; set; }
         //Get list OrderDetail
        public virtual ICollection<OrderDetail> OrderDetails { get; set; }
    }
}
