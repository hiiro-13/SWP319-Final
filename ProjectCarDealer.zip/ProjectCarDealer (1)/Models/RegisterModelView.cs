﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ProjectCarDealer.Models
{

    public class RegisterModelView
    {   
        //name RegisterModelView
        [DisplayName("User Name")]
        [Required(ErrorMessage = "UserName cannot be blank")]
        public string name { get; set; }
        //email RegisterModelView
        [DisplayName("Email")]
        [Required(ErrorMessage = "Email cannot be blank")]
        [EmailAddress(ErrorMessage = "E-mail is not valid")]
        public string email { get; set; }
        //pass RegisterModelView
        [DisplayName("Password")]
        [Required(ErrorMessage = "Password cannot be blank")]
        [DataType(DataType.Password)]
        [StringLength(15, ErrorMessage = "Passwords must be at least 6 characters", MinimumLength = 6)]
        public string pass { get; set; }
        //confirmPassword RegisterModelView
        [DisplayName("Confirm Password")]
        [Required(ErrorMessage = "Confirm Password cannot be blank")]
        [DataType(DataType.Password)]
        [Compare("pass", ErrorMessage ="Comfirm Password doesn't match ")]
        public string confirmPassword { get; set; }
        //firstname RegisterModelView
        [DisplayName("First name")]
        [Required(ErrorMessage = "First name cannot be blank")]
        public string firstname { get; set; }
        //lastname RegisterModelView
        [DisplayName("Last name")]
        [Required(ErrorMessage = "Last name cannot be blank")]
        public string lastname { get; set; }
        //birthday RegisterModelView
        [DisplayName("Birthday")]
        [Required(ErrorMessage = "Birthday cannot be blank")]
        public DateTime birthday { get; set; }
        //Gender RegisterModelView
        [DisplayName("Gender")]
        public string Gender { get; set; }
        //phone RegisterModelView
        [DisplayName("Phone number")]
        [Required(ErrorMessage = "Phone number cannot be blank")]
        public string phone { get; set; }
        //address RegisterModelView
        [DisplayName("Address")]
        [Required(ErrorMessage = "Address cannot be blank")]
        public string address { get; set; }
    }
}
