﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ProjectCarDealer.Models
{
    public partial class Category
    {
        public Category()
        {
            Products = new HashSet<Product>();
        }
        //CatId Category
        public int CatId { get; set; }
        //CatName Category
        public string CatName { get; set; }
        //Get list Product
        public virtual ICollection<Product> Products { get; set; }
    }
}
