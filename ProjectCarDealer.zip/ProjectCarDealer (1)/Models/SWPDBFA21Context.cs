﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace ProjectCarDealer.Models
{
    public partial class SWPDBFA21Context : DbContext
    {
        public SWPDBFA21Context()
        {
        }

        public SWPDBFA21Context(DbContextOptions<SWPDBFA21Context> options)
            : base(options)
        {
        }
        //Get list Gallery
        public virtual DbSet<Gallery> Gallery { get; set; }
        //Get list Account
        public virtual DbSet<Account> Accounts { get; set; }
        //Get list Cart
        public virtual DbSet<Cart> Carts { get; set; }
        //Get list Category
        public virtual DbSet<Category> Categories { get; set; }
        //Get list OrderProduct
        public virtual DbSet<OrderProduct> OrderProducts { get; set; }
        //Get list Product
        public virtual DbSet<Product> Products { get; set; }
        //Get list OrderDetail
        public virtual DbSet<OrderDetail> OrderDetail { get; set; }
        //Get list TransactionMethod
        public virtual DbSet<TransactionMethod> TransactionMethods { get; set; }
        
        //put database
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Server=LAPTOP-K6DVUF6L;Database=SWPDBFA21;Integrated Security=true;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "Vietnamese_CI_AS");

            modelBuilder.Entity<Account>(entity =>
            {
                entity.HasKey(e => e.AccId)
                    .HasName("PK__Account__91CBC398D9D284B7");

                entity.ToTable("Account");

                entity.Property(e => e.AccId).HasColumnName("AccID");

                entity.Property(e => e.AccAvt)
                    .HasMaxLength(3000)
                    .IsUnicode(false);

                entity.Property(e => e.Address)
                    .IsRequired()
                    .HasMaxLength(255);

                entity.Property(e => e.Birthday).HasColumnType("date");

                entity.Property(e => e.DateCreated).HasColumnType("date");

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.Firstname)
                    .IsRequired()
                    .HasMaxLength(255);

                entity.Property(e => e.Lastname)
                    .IsRequired()
                    .HasMaxLength(255);

                entity.Property(e => e.Phonenumber)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Username)
                    .IsRequired()
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.Userpassword)
                    .IsRequired()
                    .HasMaxLength(32)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Cart>(entity =>
            {
                entity.ToTable("Cart");

                entity.Property(e => e.CartId).HasColumnName("CartID");

                entity.Property(e => e.AccId).HasColumnName("AccID");

                entity.Property(e => e.DateCreated).HasColumnType("date");

                entity.Property(e => e.PodId).HasColumnName("PodID");

                entity.HasOne(d => d.Acc)
                    .WithMany(p => p.Carts)
                    .HasForeignKey(d => d.AccId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Cart__AccID__2F10007B");

                entity.HasOne(d => d.Pod)
                    .WithMany(p => p.Carts)
                    .HasForeignKey(d => d.PodId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Cart__PodID__300424B4");
            });

            modelBuilder.Entity<Category>(entity =>
            {
                entity.HasKey(e => e.CatId)
                    .HasName("PK__Category__6A1C8ADAD4AC99C9");

                entity.ToTable("Category");

                entity.Property(e => e.CatId)
                    .ValueGeneratedNever()
                    .HasColumnName("CatID");

                entity.Property(e => e.CatName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<OrderProduct>(entity =>
            {
                entity.HasKey(e => e.OrdId)
                    .HasName("PK__OrderPro__67A283165D583E72");

                entity.ToTable("OrderProduct");

                entity.Property(e => e.OrdId).HasColumnName("OrdID");

                entity.Property(e => e.AccId).HasColumnName("AccID");

                entity.Property(e => e.DateCreated).HasColumnType("date");

                entity.Property(e => e.PodId).HasColumnName("PodID");

                entity.Property(e => e.TraId).HasColumnName("TraID");

                entity.HasOne(d => d.Acc)
                    .WithMany(p => p.OrderProducts)
                    .HasForeignKey(d => d.AccId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__OrderProd__AccID__34C8D9D1");

                entity.HasOne(d => d.Pod)
                    .WithMany(p => p.OrderProducts)
                    .HasForeignKey(d => d.PodId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__OrderProd__PodID__35BCFE0A");

                entity.HasOne(d => d.Tra)
                    .WithMany(p => p.OrderProducts)
                    .HasForeignKey(d => d.TraId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__OrderProd__TraID__36B12243");
            });

            modelBuilder.Entity<Product>(entity =>
            {
                entity.HasKey(e => e.PodId)
                    .HasName("PK__Product__69F90ADE159FC2F1");

                entity.ToTable("Product");

                entity.Property(e => e.PodId).HasColumnName("PodID");

                entity.Property(e => e.AccId).HasColumnName("AccID");

                entity.Property(e => e.CatId).HasColumnName("CatID");

                entity.Property(e => e.DateCreated).HasColumnType("date");

                entity.Property(e => e.GearType)
                    .IsRequired()
                    .HasMaxLength(255);

                entity.Property(e => e.PodDescription)
                    .IsRequired()
                    .HasMaxLength(3000);

                entity.Property(e => e.PodImage)
                    .IsRequired()
                    .HasMaxLength(3000)
                    .IsUnicode(false);

                entity.Property(e => e.PodName)
                    .IsRequired()
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.Price)
                    .HasColumnType("decimal(15, 2)")
                    .HasDefaultValueSql("('0.00')");

                entity.Property(e => e.VinNumber)
                    .IsRequired()
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.HasOne(d => d.Acc)
                    .WithMany(p => p.Products)
                    .HasForeignKey(d => d.AccId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Product__AccID__2B3F6F97");

                entity.HasOne(d => d.Cat)
                    .WithMany(p => p.Products)
                    .HasForeignKey(d => d.CatId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Product__CatID__2C3393D0");
            });

            modelBuilder.Entity<TransactionMethod>(entity =>
            {
                entity.HasKey(e => e.TraId)
                    .HasName("PK__Transact__E6FDEF304003B9C1");

                entity.ToTable("TransactionMethod");

                entity.Property(e => e.TraId).HasColumnName("TraID");

                entity.Property(e => e.Amount).HasColumnType("decimal(15, 2)");

                entity.Property(e => e.DateCreated).HasColumnType("date");

                entity.Property(e => e.Message)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.Payment).HasMaxLength(255);

                entity.Property(e => e.PaymentInfo)
                    .IsRequired()
                    .HasColumnType("text");

                entity.Property(e => e.Security)
                    .HasMaxLength(16)
                    .IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }

   
}
